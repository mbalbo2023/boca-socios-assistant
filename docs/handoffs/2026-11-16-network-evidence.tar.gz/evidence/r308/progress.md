# SDD ledger — plan: docs/superpowers/plans/2026-11-15-r308-observed-opening.md

Base implementation98ab1f3 (docs only over main1ab24a6). Spec and plan committed;
issue529 contains four prior votes. Root owns docs/integration; dedicated author
owns the eight Task1 paths. No host operation or product code yet.

## Preflight

| Pair/task | Producer/consumer or internal contract | Finding |
|---|---|---|
| Task1/Task2 | Four product modules and tests feed one integrated candidate | Root does not edit author paths; independent reviews before publication. |
| Task1 protocol/observer | parse_queue_opening_time and exact fields | Parser in protocol prevents circular dependency or duplicated date semantics. |
| Task1 coordinator/UI | int>=0 or None and informative UTC date | Both HTML/polling use same semantics; failed poll retires live value. |
| Task1 internal | Tests cover all five review risks and exact formats | Consistent; no provider availability gate or extra timer. |
| Task2 internal | Reviewed diff then exact checks and promotion | Telegram binding dependency must be resolved before new installation. |

Ruling: reuse the existing isolated worktree and its toolchain; no fresh baseline
suite. The base tree has certified CI9844+34. Run only meaningful delta tests;
full applicable CI belongs to the eventual exact published candidate.

Task1: implemented in 72195d97923f6bc7cf8b293eb34c1910d87cd919. Report in
task-1-report.md records 235 distinct passing cases across the first focal
execution and nine corrected fixture selectors; no second full focal run.
Independent architecture/QA/ops/root review in progress.

Integration: root checked two previously unrun boundaries. Standalone stdlib
IPC imports PASS; offline HTTP fixture test FAIL because 165160 bytes exceed
160000. Four explicit prior votes approve only the runner/test cap at 170000;
separate author to correct and verify failed/oversize cases. No host or push.
