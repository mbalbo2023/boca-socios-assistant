# R308 adenda — límite de fixture UI offline

Estado: DONE. Base d839232; commit 67f932dfdb349c2c006d8e08b7b6155e3437fd71.
Autor separado, únicamente dos rutas y dos sustituciones numéricas:
`scripts/run_engine_dashboard_ui_offline_chromium.py` (_MAX_FIXTURE) y
`tests/test_engine_dashboard_ui_offline.py` (aserción existente),160000→170000.
Ningún validador, otro cap, producto o minificación cambió.

RED causal aportado por root antes de estas fuentes, registrado en adenda/issue529 comment6902922340:
`test_http_fixture_models_all_native_redirects_and_preserves_poll_document` falló porque validate_fixture rechazaba165160>160000. La inspección temporal del root era medida en memoria, no PASS. Alcance aprobado4/4.

GREEN ejecutado por autor:
`.venv/bin/python -m pytest -q tests/test_engine_dashboard_ui_offline.py::test_http_fixture_models_all_native_redirects_and_preserves_poll_document 'tests/test_engine_dashboard_ui_offline.py::test_fixture_rejects_source_drift_private_metadata_and_unreviewed_inputs[fixture_size]'`
Resultado:2 PASS, exit0,0.23s; log offline-cap-green.log.

Sondeo focal adicional en memoria con fixture real y hashes recalculados, sin editar otros archivos:
fixture original165160B; JSON exacto170000B aceptado;170001B rechazado por offline_fixture_unverified; exit0. Se preserva el borde estricto (>cap) y el rechazo oversize.

`.venv/bin/ruff check scripts/run_engine_dashboard_ui_offline_chromium.py tests/test_engine_dashboard_ui_offline.py`:All checks passed, exit0.
`.venv/bin/ruff format --check scripts/run_engine_dashboard_ui_offline_chromium.py tests/test_engine_dashboard_ui_offline.py`:2 files already formatted, exit0.
`git diff --check`:exit0.

No se repitieron235 casos, import IPC ni suite completa. Sin push/PR/host/proveedor/Docker/BLACKBOX. Siete documentos root ya modificados quedaron fuera del commit e intactos por este autor. Revisión independiente final e integración quedan en root; este autor no cuenta como aprobación propia.
