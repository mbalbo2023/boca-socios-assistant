# R309 — Task 1 author report

## Result and ownership

Implementation commit: **bb0b0227a5d99616741f033d06f6f48b2a247b7e**.
Branch: `feature/529-r308-countdown`.
Author role: `/root/r309_author`, separate implementer; **no independent GO vote**.

The commit contains exactly the ten authorized product/test routes. It excludes the two documentation files currently modified by root. No push, PR, CI dispatch, host, SSH, Docker daemon, provider, or Telegram operation was performed by the author. Docker and filesystem effects in tests use external I/O fixtures; actual lease, binding, profile, parser, codec, and coordinator validators execute locally.

Initial authorization: D1–D10, four prior GO in issue 530, design/plan committed at `5432afe`. Before enlarging the installed source bound, root recorded the four-vote adenda in issue 530 comment **6903247627**, documentation commit **70d4160**. That adenda adds the builder and one existing R296 aggregate assertion to the original eight-route ownership.

Committed routes:

- `.github/workflows/boca-first-deploy.yml`
- `scripts/boca_protected_memfd_bootstrap.py`
- `scripts/build_protected_telegram_bundle.py`
- `src/boca_socios/host_telegram_backend.py`
- `src/boca_socios/host_telegram_cli.py`
- `src/boca_socios/host_telegram_maintenance.py`
- `src/boca_socios/host_telegram_status.py`
- `tests/test_r296_telegram_installed_bundle.py` — aggregate assertion only
- `tests/test_r309_telegram_prepare_diagnose.py`
- `tests/test_r309_telegram_prepare_transport.py`

## Implemented contract

**D1/D2.** The new coordinator is bound to installed source `845f31abfb1762dff27e6fc3274fcc40507f3f18`, APPLY run `43704768556`, incident run `43738415332`, and the fixed reviewed controller/worker IDs and image digests. It validates a fresh lease, the current installed binding, healthy controller, stopped worker and engine, and explicitly rejects any registered sender, extra container/helper, or custody writer. An existing Telegram volume must have the exact canonical identity and mountpoint. An absent volume is recorded without creation or mounting.

The explicit sender test first proves that the real `resolve_installed_context` and `healthy()` accept a correctly registered **stopped** sender, then proves that the diagnostic guard rejects it. Sender absence is therefore not attributed merely to healthy.

**D3.** Public A/B are fixed literal programs executed in the exact controller as UID/GID 10001 with `/app/.venv/bin/python -I -B`. The programs read only the two public documents, using no-follow metadata, bounded file reads, and the R parsers. Declared source is validated before comparison with R. Historical observation run/date survive without a TTL300 rejection. Invalid public bytes and exceptions never enter the receipt. No SQL or `load_telegram_admin` wrapper is called.

**D4/D5.** `recipient-observe` accepts only an empty request, reuses factory action `recipient`, and leaves MOUNTS unchanged. Its only command difference is an exact literal program, which is also attested. There is one helper attempt, with the original restricted recipient profile and read-only Telegram mount. Two snapshots use new descriptors and at most two directory entries per snapshot. Private bytes are read and derived only for KEY_ONLY plus regular0400/10001:10001/nlink1/size32. Extras and invalid metadata do not read private bytes. ENOENT under a valid parent, I/O uncertainty, invalid metadata, and drift remain distinct. Invalid-parent metadata also contributes a witness, so a change between invalid states cannot look stable.

**D6.** Sequence: guards → public A → one helper/double snapshot → public B → guards. The helper is stopped with exact `stop -t 5` and removed only while its identity/profile remain attested. A lost ACK or changed Cmd preserves the uncertain helper; there is no retry or second helper. The reached CID, attempted effects, and RETIRED/INDETERMINATE retirement remain in the receipt. Lease-close uncertainty in CLI downgrades a previously complete receipt while retaining the reached retired CID.

**D7.** The dedicated frame prefix is `BOCA_TELEGRAM_PREPARE_DIAGNOSIS_V1 `. The entire canonical frame, including prefix and final LF, is limited to 4096 bytes. Fields and nested objects are closed; identifiers, hashes, timestamps, phases, reasons, and states have finite validation. V1 backend receipts and their 1024-byte verifier remain unchanged. The new verifier rejects cross-protocol input, extra fields, duplicate keys, incorrect coordinates, missing absence witnesses, changed authorization/write fields, noncanonical framing, and overflow. Public and helper pipes are bounded during acquisition, not merely after an unbounded capture.

**D8.** Observations yield non-executable recommendations. Every receipt has data/custody/status writes = 0, prepare/adopt_authorized = false, stage NOT_INSPECTED, and historical_cause UNDETERMINED. Admin invalid/mismatch and invalid/mismatched public evidence block an actionable-looking recommendation. Incomplete acquisition, transport, postflight, or retirement produces INCOMPLETE_NO_GO and PRESERVE_REVIEW.

**D9/D10.** The selector is wired into installed admission, budget, case selection, workflow-main SHA selection, ancestry/build, dispatch, CLI/selftest/verifier, and memfd installed mode. BOCA_SOURCE_SHA remains submitted R, independently from workflow W/GITHUB_SHA. All five legacy steps explicitly exclude the selector, including always-stop. The result branch accepts a complete diagnosis only with both remote_rc=0 and verification_rc=0; it never prints PREPARED or the generic OWNER_ACCEPTANCE epilogue. ZIP selftest, isolated verifier, memfd dispatch, and default V1 representative behavior are exercised without host access.

## Final D2 finding from author review

After the main focal run, author review found a concrete gap: the legacy mount profile validator checks named mounts but does not authenticate their Docker `Source` field. A Source using `boca_data/../boca_telegram/_data` passed the initial new diagnostic guard and incorrectly reached OBSERVED_NO_GO.

`red-writer-alias.log` records that causal failure. The diagnostic-only guard now requires the canonical Source for every named volume of the approved pair, in addition to explicit Telegram custody exclusion. Legacy validators were not edited. External Docker fixtures now supply actual canonical Source fields. `green-writer-alias.log` covers the new rejection plus affected positive guards, registered sender, postflight, CLI lease, and ZIP paths.

## Causal RED / GREEN evidence

Logs are in `.superpowers/sdd/r309/`. Counts below describe their actual runs; overlapping cases are not added together.

| Boundary | Actual RED evidence | GREEN evidence |
|---|---|---|
| Missing installed literals and separate entry/codec | `red-programs.log`: 22 failed | `green-programs.log`: 21 passed, 1 deselected; later focal includes separate entry/codec |
| Missing coordinator, fixed guards, helper lifecycle, recommendations | `red-circuit.log`: 20 failed | `circuit-boundary.log`: 19 passed, 31 deselected; later focal includes all guard cases |
| Missing coordinator for closed codec / negative recommendations | `red-codec.log`: 8 failed | Main focal run below |
| Missing CLI/Action selector/result handling | `red-transport.log`: 4 failed, 6 passed, 8 deselected | `green-transport.log` then `green-wiring.log`: the latter 8 passed, 10 deselected; main focal closes all |
| Old 450000 installed bound | `red-bundle-bound.log`: real builder raises source-closure bound error | `green-adenda-zip.log`: 9 passed, 11 deselected; R296 was deselected here and was run in the main focal command |
| Installed aggregate500000 boundary | `red-adenda-boundaries.log`: 1 failed | New aggregate/individual memfd tests and builder exact-boundary tests pass |
| Invalid-parent drift, valid R historical states, mislabeled public coordinates | `red-deep-boundaries.log`: 4 failed | `green-deep-boundaries.log`: 4 passed, 50 deselected |
| Postflight must not report preflight as current | `deep-lifecycle.log`: 1 failed, 6 passed | `green-postflight.log`: 1 passed, 60 deselected |
| Absence witness / invalid-public precedence | `red-absence-evidence.log`: 1 failed | `green-absence-evidence.log`: 1 passed, 61 deselected |
| Noncanonical writer Source | `red-writer-alias.log`: 1 failed, 62 deselected | `green-writer-alias.log`: 19 passed, 66 deselected |

The implementation investigation also corrected test-boundary setup errors: a missing Docker volume Name field, an incorrect legacy step heading, an environment-name regex omitting digits, and an import removed while previously unused. Those setup errors are not claimed as causal product RED evidence.

### Main focal command and final delta

Main focal command, before the final Source-alias finding:

```text
.venv/bin/python -m pytest -q tests/test_r309_telegram_prepare_diagnose.py tests/test_r309_telegram_prepare_transport.py tests/test_r296_telegram_installed_bundle.py::test_installed_transport_has_exact_independent_bounds_and_modes
```

Actual result: **85 passed in 7.03s** (`final-focal.log`). This includes only the one historical R296 case whose aggregate assertion the adenda changes. No R308 baseline or broad historical suite was repeated.

After the new causal Source-alias test/fix, only affected cases were selected:

```text
.venv/bin/python -m pytest -q tests/test_r309_telegram_prepare_diagnose.py -k 'guard_refuses or full_diagnosis or registered_stopped or changed_postflight' tests/test_r309_telegram_prepare_transport.py -k 'guard_refuses or full_diagnosis or registered_stopped or changed_postflight or owns_one_real or zip_and_memfd'
```

Actual result: **19 passed, 66 deselected in 2.51s** (`green-writer-alias.log`). The last `-k` expression is pytest's effective selector. The combined evidence covers **86 distinct cases**. There was **no single 86/86 run**, and none is claimed.

Quality evidence: Ruff clean and nine files formatted in the main gate; mypy clean for six source files. After the final delta, Ruff was clean over all affected Python files, format clean for the two changed files, and mypy clean for the changed backend. `git diff --check` was clean before commit. Logs: `final-ruff.log`, `final-format.log`, `final-mypy.log`, `final-delta-ruff.log`, `final-delta-format.log`, `final-delta-mypy.log`.

## Measurements and adenda boundaries

Measured from the actual installed ZIP built and exercised after the final code delta:

| Quantity | Measured | Limit |
|---|---:|---:|
| Installed entries | 47 | Exact existing closure47 |
| Installed aggregate source | 490974 bytes | 500000 |
| Largest installed entry | 40833 bytes | 450000 |
| Installed compressed ZIP | 135416 bytes | 300000 |
| Bounded synthetic codec stress frame, prefix+LF included | 2521 bytes | 4096 |

Installed source headroom: **9026 bytes**. ZIP SHA256:
`54b210fbb9aa9c049411f519d47fb9a9e7f8aa99700ebf447cc1c8d92ba42dcc`.

The first required measurement, before the adenda, was 488426 installed source bytes, delta **38426 over450000**, 47 entries and 135063 compressed bytes; the real builder rejected it. Subsequent in-scope guard/codec fixes bring the final source to490974, inside the approved500000 aggregate.

The adenda changes only the installed aggregate cap. It preserves the450000 compactor threshold, unchanged compactor algorithm,450000 individual builder/memfd limits, default450000, ZIP300000, exact47 installed entries, and CPU/RAM/PID limits. Tests distinguish aggregate500000 accepted from500001 rejected, and individual450001 rejected when the aggregate is450047 (below500000). The real builder separately tests500000/500001 and individual450001.

The earlier real default measurement was40 entries /394660 source bytes /117451 ZIP bytes, within unchanged bounds. It was not rebuilt again solely to repeat that baseline. `final-measures.json` preserves both the earlier measurement and final installed measurement. The tested final archive is retained at `.superpowers/sdd/r309/r309-installed.pyz`.

## Exact selector and recommendation interpretation

Selector for root's later reviewed workflow: **`telegram-prepare-diagnose`**.
Source input: `845f31abfb1762dff27e6fc3274fcc40507f3f18`.
Service: `controller`. Budget: `1.5cpu-1024m-192pids`.
Release input: `43704139794` (release867), with the reviewed fixed controller/browser digests. W comes from the new authenticated workflow's GITHUB_SHA and the new run ID. `failed_telegram_run_id` and `legacy_release_run_id` remain empty; incident1167 is fixed in the diagnostic and is not caller input.

| Stable result, with coherent admin evidence | Recommendation only |
|---|---|
| Public ABSENT; key VALID / KEY_ONLY | PREPARE_FINAL_REUSE_KEY |
| Public MATCH_R; derived key MATCH | PUBLIC_REBIND_REQUIRED |
| Public ABSENT; key ABSENT / EMPTY, or volume absent | PREPARE_FINAL_CREATE_KEY |
| Public MATCH_R; key absent | INCONSISTENT_PRESERVE |
| Extra custody entries with otherwise coherent public/admin states | CUSTODY_PRESENT_REVIEW |
| Invalid, mismatched, unread, changed, or incomplete evidence | PRESERVE_REVIEW |

No recommendation runs prepare, publish, rebind, or adopt. OBSERVED_NO_GO means a completed current observation with zero authorization; it is not PREPARED. INCOMPLETE_NO_GO means a required boundary was not fully observed. Cause1167 remains UNDETERMINED in both.

## Limits and handoff

The tests execute real installed parser source that is byte-identical to R and simulate only external filesystem/account/Docker I/O. They do not prove the live image dependencies, live custody state, actual public document contents, or host diagnosis; missing dependency paths are explicitly tested as NOT_READ. Root owns independent review, publication, CI, integration, any later single Action, and recording real evidence in417. The author supplied no independent approval vote.

MOUNTS, installed-image source, R307, BLACKBOX files, data/passkeys, and other projects were not modified. BLACKBOX code was not opened. No runtime authorization or sender state was changed by this implementation work.
