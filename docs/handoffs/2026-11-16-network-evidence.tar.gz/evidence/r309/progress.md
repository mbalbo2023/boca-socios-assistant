# SDD ledger — R309

Plan: docs/superpowers/plans/2026-11-15-r309-telegram-prepare-diagnose.md.
Spec: docs/superpowers/specs/2026-11-15-r309-telegram-prepare-diagnose-design.md.
Base5432afe; issue530 records four prior GO votes including D2/D5 clarifications.

Preflight table is part of the committed plan: publicR programs to host reader,
keyRO program to attested maintenance, coordinator/codec to CLI and installed
transport with all legacy exclusions. No shared product writers. Root owns
documentation, remote evidence and Actions. R308 author is finished; its10paths
are independently reviewed and separate from this diagnostic.

Task1: r309_author implementing the six product paths and two focused tests.
No source/archive cap change authorized. If installed450000 cannot contain
measured delta, author reports evidence and waits only on that adenda.
No full local baseline or duplicate R308 suites; integrated CI later.

Architecture reading baseline transport selectors to support final review;
Ops preparing exact future dispatch inputs from existing evidence only.
No host operation during implementation.

Adenda D9: measured installed488426 bytes/47entries, in-memoryZIP135063;
default394660/40entries/117451ZIP. Real builder rejected450000. Four prior GO
votes recorded in issue530/comment6903247627 and docs70d4160. Only installed
AGGREGATE becomes500000; individual/default/compactor threshold450000 remain,
ZIP300000 unchanged. Memfd must separate per-entry bound. Extra ownership:
builder and the one R296 aggregate assert (10 author paths total).

R308 final review is complete4/4. Public checkpoint branch
feature/529-r308-countdown points to d356d8118a583fc4aa2c95fa783c3b5be21422f0,
tree04ef24f50a346afae24dbb80fbe5c594a3761b65, exactly equal to local40f6c85.
git push failed for lack of CLI credentials; root published through GitHub Git
data tools and read back branch/commit/tree. No PR/CI/host was triggered.
Do not fetch/rebase/reset the shared worktree while author works. Root will
publish the final local tree on remote parentd356 and compare exact tree bytes.
Issue530 is intended to convert to the single integration PR; RCA529.fix_pr=530.

Author has reported literal/circuit/transport/size boundaries GREEN; final
quality/focal run and commit/report still pending. Reviewers must inspect final
diff and logs, not repeat suites. Root currently owns uncommitted changes in
BETA_INTEGRATION_STATUS and R309 plan only.

Architecture follow-up: adopt_sender_binding is same-version sender only;
pair upgrade preserves volumes but does not adopt Telegram public/stage/V2
marker. V2 already yields CUSTODY_COMMITTED_NO_SEND, so no new crypto needed
for first global config-only exit. Existing sender-recover branch without
journal/sender can publish status, but RECOVERED/OFF does not prove configured
VERIFIED and cannot adopt another source. Actual D8 result remains dependency.

QA recovered historical capture25 logs: two runs41512196530/41537796470,
no artifacts; source bodies deliberately deleted and neither render/auth
succeeded. No later capture in340dispatches. This lead is closed in
issue12/comment6903198722; do not repeat it or claim frontend contract recovered.
