# Boca Socios Assistant — cierre técnico antes de la prueba integral

El titular pidió terminar los pendientes y después realizará su prueba integral. **Todavía no está acreditada la BETA integral.** Root mantiene integración, documentación y la única Action. Autores separados; Arquitectura, QA, Operaciones y root revisan cada delta.

| Frente activo | Estado y ownership |
|---|---|
| PR530 integrado R308/R309 | MERGED en main b3200f7bc4391156205dab992989a609253ec6ee, árbol a730e2f595d2cf4dc762c41b021b2366674afccc verificado;0 PR abiertos. CI1282 del candidato SUCCESS:10015 tests+34 subtests. CI1283/main y Security1094 en progreso. Sin host. Root espera gates antes del diagnóstico. |
| R308 — apertura observada | Producto72195d9 y corrección67f932d revisados4/4;235 casos distintos PASS y cierre focal de fixture170000. Incluido en530, todavía no desplegado. Autor liberó ownership. |
| R309 — diagnóstico Telegram | Producto25ed05e y adenda test-only35dffc1 aprobados4/4 e integrados. CI1282 completa PASS;1281 conserva el fallo histórico ya corregido. ZIP y producto idénticos tras la adenda. Root opera un diagnóstico tras gates de main; todavía no PREPARED ni causa1167. |
| Telegram por socio | Diseño de QA, sin código autorizado; depende de custodia global y adopción durable entre versiones. No sustituir por formularios aislados. |
| DOM autenticado y resultado real | Contratos/evidencia acreditada aún faltantes. Arquitectura y QA; no declarar cierre con relatos previos de login o resultados sintéticos. [Matriz funcional](https://github.com/mbalbo2023/boca-socios-assistant/issues/12#issuecomment-6903029338). |
| Capacidad50 | Issue531 C1–C10 aprobado4/4 antes de código; autor separado r308_author trabaja sólo3 rutas en worktree boca-capacity50. Runner offline, pool/registry reales, perfil1CPU/768MiB/128PID,600/15/650s y32768B. Sin PR, despacho ni host antes del diagnósticoR309. |
| Producto y host | Sigue R845f31abfb1762dff27e6fc3274fcc40507f3f18, release867/APPLY1153. Recovery1166 y observación1170 cerradas; no nueva operación de host. |

Pendiente crítico: CI/main y Security GREEN, una ejecución de diagnóstico y decisión basada en su recibo. La configuración individual, contratos DOM/resultado, medida física50, promoción consolidada y aceptación privada siguen abiertos. No presentarlos como si fueran sólo QA del titular.

[Checkpoint canónico](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6899119716). SIMULATION_ONLY, senderOFF, BLACKBOX y recursos ajenos protegidos.

---

## Corte histórico después de1170

**Docker BETA instalado; R307 integrado y observado. Telegram PREPARED y la BETA integral siguen pendientes.** Última observación física: [1170/run43749877557](https://github.com/mbalbo2023/boca-socios-assistant/actions/runs/43749877557), 15-Nov-2026 19:00:27UTC (16:00:27ART). Controller exactohealthy/running, worker exactocreated/PID0 y helper1167ABSENT. Engine lógicoUNVERIFIED; cero escrituras y autorizacionesfalse. No atribuir causa ni declararPREPARED por ausencia del helper.

| Elemento | Estado vigente |
|---|---|
| Producto instalado R | `845f31abfb1762dff27e6fc3274fcc40507f3f18`; release867/APPLY1153 ACCEPTED/cleanupACCEPT. No nuevo deploy. |
| Main operativo R307 | `1ab24a696bf473f57cdae1ee1f01af024ce1b8e8`; [PR528 merged](https://github.com/mbalbo2023/boca-socios-assistant/pull/528); CI1280/run43748849547 y Security1093/run43748849599 SUCCESS; PR0. |
| Recuperación1166 | ACCEPTED, inicializador retirado. Cerrada. |
| Preparación1167 | FAILED_STATE_PRESERVED/restauraciónsaludable/motorOFF/senderOFF en ese recibo; causa histórica desconocida. No se repitió. |
| Diagnóstico1170 | OBSERVED_NO_GO/COMPLETE/NONE; [recibo físico y límites](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6899708285). Cerrado. |
| Ownership y próximo paso | [Checkpoint canónico de este chat](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6899119716): root integra/opera; Operaciones/RCA investiga; Arquitectura y QA revisan; autorR307 terminado. |

1169 fue un presupuesto de formulario incorrecto de root, rechazado PRE-SSH. Corregido por consenso4/4 sin código, usando nuevo attempt1 del mismo main: budget1.5cpu-1024m-192pids, servicecontroller y22 campos textuales vacíos.1170 fue la única observación física nueva. No repetir1170, recuperación1166, prepare, release, APPLY, admin o migración para diagnosticar.

## Camino crítico inmediato

Fijar **qué lector/transporte existente** permitirá observar conjuntamente los dos recibos públicos (destinatario y admin_status) y sólo metadatos de custodia/clave, con binding/installation_fingerprint/observation_run_id, dos lecturas estables y clasificación de ausencia/invalidez/desactualización/no leído. Esa Action no existe todavía; la UI ofrece información parcial. Root+Operaciones poseen el diseño; equipo4/4 revisa el contrato antes de cualquier código. No nuevo helper, SQLite, llamadaTelegram ni lectura de secretos. Sólo esa evidencia puede justificar una continuación posterior preservando posibles estados parciales.

## Pendientes hasta la BETA integral

Motores independientes, monitores, panel y wiring existentes se conservan. Quedan desarrollo/integración de DOM autenticado, countdown, resultado confirmado/ganador/cancelación y comprobante/foto/destino por socio. También preparación/emparejamiento/aceptación Telegram, QA privado Samsung/Voice Access y capacidad física50 medida. No presentar todo eso como simples pruebas del titular. SIMULATION_ONLY; datos/passkeys/BLACKBOX y Porota/PPI preservados.

<details>
<summary>Archivo histórico anterior a R307/1170 — no reabrir sus tareas cerradas</summary>

# Boca Socios Assistant — continuidad recuperada, Telegram1167 (15-NOV-2026 ART)

**Docker BETA instalado y conservado. Telegram PREPARED y aceptación funcional integral siguen pendientes.** La última observación física recuperada (prepare1167, 15-Nov13:59 ART) acredita restauración del controller saludable, motor OFF y sender OFF; no es una lectura nueva del host.

| Elemento | Estado vigente y evidencia |
|---|---|
| Aplicación instalada R | `845f31abfb1762dff27e6fc3274fcc40507f3f18`, release867/run43704139794, [APPLY1153 ACCEPTED/cleanupACCEPT](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6893143766) |
| Main operativo W2 | `e16bfb78bc16b9f7554c76191c50f354e61fcbbc`, PR527 merged; CI1278/run43737503378 y Security1092/run43737503384 SUCCESS; 0 PR abiertos al reconciliar esta continuidad |
| Recuperación Telegram1166 | [COMPLETE/ACCEPTED, inicialización aceptada y auxiliar retirado](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6898002351); NO repetir |
| Preparación Telegram1167 | [FAILED_STATE_PRESERVED; CONTROLLER_HEALTHY_ENGINE_OFF; senderOFF; humanUNVERIFIED](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6898066194). No PREPARED, causa concreta no conservada en el recibo |
| Ownership | Root de la sesión que retoma «Estado de Telegram» asume integración/documentación/Actions únicas por instrucción explícita del titular; revisores independientes de continuidad, RCA y funcionalidad. [Registro y consenso4/4 de diagnóstico](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6899119716) |

No repetir release867, APPLY1153, ADMIN1154, migración1150, recuperación1166 ni prepare1167 para diagnosticar. El estado indeterminado de1156 es histórico y no sustituye la restauración comprobada de1167. Se revisa la adaptación mínima del observador existente al nuevo incidente; no hay todavía cambio productivo justificado ni consenso sobre uno.

Dos motores independientes, tres familias de navegador y presupuesto global50 lógico ya tienen implementación. DOM autenticado, countdown, resultado confirmado/ganador/cancelación, comprobante/foto/destino por socio y aceptación privada siguen pendientes de desarrollo, integración o evidencia según la [matriz canónica](https://github.com/mbalbo2023/boca-socios-assistant/blob/e16bfb78bc16b9f7554c76191c50f354e61fcbbc/docs/BETA_INTEGRATION_STATUS.md); no presentarlos como simples pruebas del titular. Capacidad física50 no certificada. SIMULATION_ONLY; datos/passkeys/BLACKBOX preservados; host sólo Actions Boca; Porota/PPI fuera de alcance.

---

## Archivo histórico del corte1156 — sustituido por la cabecera anterior

# Boca Socios Assistant — R303 / incidente Telegram posterior (15-NOV-2026 UTC)

**R está instalado, pero el último estado del panel requiere comprobación tras el fallo de telegram-prepare #1156. No declarar cierre integral ni restauración saludable.**

- Main/instalado: `845f31abfb1762dff27e6fc3274fcc40507f3f18`, tree `f360328ed36e4d738a957ae56f40791728ef5cd9`, PR524 merged. Gates main CI1270/Security1089 SUCCESS.
- Release867/run43704139794: manifiestos verificados, controller9fc622a…/worker1a59e0b….
- APPLY1153/run43704768556: ACCEPTED/cleanupACCEPT. ADMIN1154 PROVISIONED/sector2/legacy0. STATUS1155 HEALTHY/STOPPED corresponde al instante anterior al incidente.
- PREPARE1156/run43705714873: FAILED_STATE_PRESERVED, restorationINDETERMINATE, senderOFF, humanUNVERIFIED. Sin PREPARED/activación/envíos.
- Observación actual READ_ONLY #1157/run43705926587 solicitada una vez; revisión causal en paralelo sin modificar código.

[Incidente y evidencias](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6893219798). No repetir migración1150, release867, APPLY1153, admin1154 ni prepare1156. La próxima acción depende del recibo postincidente y de una causa revisada; no usar finalizadores históricos ni ampliar acceso.

Dos motores independientes, tres familias de navegador y presupuesto global50 lógico están desarrollados. La capacidad física50, DOM autenticado, countdown, reserva confirmada, ganador/cancelación, foto/comprobante y aviso exclusivo por entrada/destino por socio siguen abiertos; no se trasladan como meras pruebas del propietario. Aceptación visual privada pendiente. SIMULATION_ONLY, datos/claves/passkeys/BLACKBOX/caps preservados; servidor sólo mediante Actions Boca; Porota/PPI fuera de alcance.

---

## Archivo histórico anterior a R299/R300 — no describe el estado actual

# Boca Socios Assistant — continuidad CANÓNICA R100 (07/11/2026 ART)

> **Estado: rediseño V3 CODE_ONLY EN CURSO. BETA integral NO instalada.** La autorización del titular permanece vigente hasta instalación física validada; no pedir otra vez email, códigos o actualización manual de hashes.

| Campo | Hecho verificado |
|---|---|
| Código base | `main=7c5d325df62509b41492acd1d3b3c0961dbef124`, PR #439 integrado, 0 PR OPEN en último censo |
| QA y release históricos | 5.344 PASS +34 subtests, CI GREEN de R97; release dual #750 SUCCESS, PREPARE #851 SUCCESS, pero **NO autorizan nuevos efectos V3** |
| Último host | #849 READ_ONLY: controlador legacy RUNNING/healthy en `127.0.0.1:8443`; #848 limpió stage anterior; Cutover #844 NO_GO y fase causal INDETERMINADA |
| Orden nueva del titular | Abandonar PREPARE → edición manual variable Environment GO_B → APPLY. Un único `workflow_dispatch` autenticado del owner para Cutover de simulación, SHA/digests descubribles automáticamente, sin hashes/correos/códigos del usuario |
| Environment observado | `boca-first-deploy`: Required reviewers OFF, wait timer OFF, branch permitida `main`, secretos intactos; [recibo R100](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6711632329) |
| Trabajos | P0: contrato Cutover V3 + tests, arquitectura/QA/security + CI exact-SHA. P1 aislados: receipt de fase, recovery manifest y optimización CI; no introducir cambios P1 en artefacto P0 |
| Próximo GO de efecto | **Ninguno todavía.** Primero PR P0, checks, release exact SHA; después única Action effectful V3 y ACK/postflight persistente. Falta de ACK/cleanup = NO_GO/INDETERMINATE sin retry ciego |

**R100 decisión y límites:** [mandato actual/acta](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6711601680) · [configuración verificada](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6711632329) · [R99 RCA sistémico #417](https://github.com/mbalbo2023/boca-socios-assistant/issues/417#issuecomment-6711404039). La aprobación se atribuye al dispatch autenticado, no a un hash autocalculado que simule un segundo GO. Se retienen rootless UID10001, volumen/owner/passkey, Chrome sin navegación real, loopback 8443, ninguna reserva/ticket real, Boca-only Docker/cleanup, no acceso host fuera de Actions, Porota/otros workloads intocables. Los dos blackboxes propietarios no se inspeccionan ni cambian.

**Histórico R99 (no vigente para el procedimiento):** [R99](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6711406080) y [R98](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6711238024) documentan SHA, release y GO_B previos. No volver a ejecutar sus pasos manuales. Regla84: actualizar esta cabecera tras próximo PR/merge/receipt real.

---

## Archivo de decisiones y checkpoints anteriores (no representa el estado actual)

# Archivo histórico de continuidad de Boca Socios Assistant

[Checkpoint HISTÓRICO — NO vigente: PR #226 integrado en `main=4b1d219c`, núcleo Chrome un uso verificado; host/URL real pendientes #225 y #209, BETA sin instalar](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6563012208). Ver [checkpoint anterior Docker cleanup `8a7bcf4`](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6561082322) y anteriores para historial. Revalidar main, Actions y permisos antes de operar.

[Plan paso a paso para BETA funcional en el droplet](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6551577529): pendientes, opciones, recomendaciones, criterios de cierre y paralelización. [Inicio autorizado, alta privada requerida y ubicación de datos delegada](https://github.com/mbalbo2023/boca-socios-assistant/issues/45#issuecomment-6551681142). [Plan versionado B1–B10 y matriz completa de funciones](https://github.com/mbalbo2023/boca-socios-assistant/blob/213be4903669c6e88122a536ad8fee6785c997ac/docs/BETA_DELIVERY_PLAN.md) integrado por #153. Este plan distingue preparación, código integrado y operación validada.

## Alcance vigente

- Aprobados: comenzar el plan recomendado para BETA de simulación, alta privada de usuarios, desarrollo e integración revisados, análisis/mejoras de eficiencia conservando integridad y documentación continua. Ubicación de la base delegada al agente: `/data/boca.sqlite3` en volumen persistente `boca-socios_boca_data`, clave separada. Correcciones previas #136/#140/#141/#142 ya integradas.
- Completar implementación y pruebas rutinarias dentro del plan aprobado sin pedir de nuevo el mismo permiso. Nuevas decisiones fuera de ese alcance (incluido mecanismo concreto de identidad/acceso) requieren opciones y recomendación. Servicio rootless dedicado preparado en #120 conforme a la recomendación aceptada; continuar sobre esa configuración y no repetir primera preparación. Único operador host coordinado.
- La instalación/release final requiere presentar el candidato concreto validado conforme al plan. Sin migraciones sobre datos existentes por inferencia. Backup/restore diferido hasta versión productiva fiable. No credenciales reales, login, cola ni reservas; Porota/PPI Watch intocables.
- **Regla 84:** documentación sincronizada con cambios y evidencia. Distinguir comprobado/configurado/propuesto/no verificado; actualizar documentos afectados y checkpoint antes de cerrar cada entrega; conservar históricos identificados, nunca presentar datos viejos como actuales.
- Un escritor por alcance; pruebas y desarrollos independientes en paralelo; merges y operaciones host seriales. Registrar revisión técnica del candidato exacto y checks completos antes de integrar. El ruleset exige PR, squash, base actualizada y quality-and-tests/image-build; no inventar requisito de revisor humano adicional.
- Operaciones host exclusivamente por workflow Boca protegido, sin repetir un run fallido. Ante un hallazgo, diagnosticar antes de remediar; nunca usar acceso a otros proyectos.

## Hechos confirmados y límites

Docker y herramientas rootless ya estaban disponibles. La nueva [ejecución #120](https://github.com/mbalbo2023/boca-socios-assistant/actions/runs/41262650418) preparó, inició y verificó el servicio rootless dedicado: SERVICE_READY sobre `6be606f83c5a6afe0ba7226abbca6a09276d1ca1`. Sustituye el estado de unidad/socket de #98; no habilita aún instalación de la aplicación. No reejecutar prepare-rootless sobre la configuración creada. **Ubicación/existencia global de base Boca en droplet no verificada.** La inspección #98 encontró ausentes DB/WAL/SHM en tres ubicaciones candidatas exclusivas de Boca; no abrió archivos ni permite inferir ausencia fuera de esas rutas. /data/boca.sqlite3 y boca-socios_boca_data son configuración, no prueba de datos desplegados. La ubicación lógica de la BETA queda decidida como arriba; #120 no creó DB, clave, volúmenes de aplicación ni contenedores. No se reemplaza almacenamiento existente por inferencia.

Cierre de esta entrega: main `213be4903669c6e88122a536ad8fee6785c997ac`, CI41263234770 y scan41263234803 PASS; 699pruebas+29subtests en5.76s, RCA12/32. El source del recibo host120 sigue siendo6be606; un merge documental posterior no altera esa observación. PR #130, #128, #134, #146, #148, #149, #150 y #152 integrados con revisión y Actions de sus candidatos; 699 pruebas +29 subtests en #152. Hay coordinación durable, lectura WSGI, formulario de alta privado y comandos de simulación internos; todavía no existe servidor/auth real ni interfaz operativa compuesta. #150 implementa la preparación rootless ya ejecutada en #120; #152 cerró #151 con cuatro escenarios de aceptación interna. Documentación central #144 completada por #153: nueve documentos, plan de entrega, matriz Site/panel y regla84 reconciliados. Site #113 sigue privado sintético sin conexión a DB ni acciones reales. [Matriz completa de funciones y pendientes](https://github.com/mbalbo2023/boca-socios-assistant/issues/113#issuecomment-6551915021). El controlador actual inicializa almacenamiento y permanece con motor apagado; no usarlo como inspección sin escritura.

Los checkpoints anteriores conservan valor histórico; sus SHAs, permisos y pendientes no reemplazan la dirección vigente.

</details>
